#include "node.h"

Node::Node(int val) {
    value = val;
    next = NULL;
    prev = NULL;
}
